package testemail;

import java.io.File;

import org.eclipse.jgit.api.Git;

public class LicenseUtil 

{

}
