package testemail2;

import java.io.File;

import org.eclipse.jgit.api.Git;

public class SerialNumberValidator

{

}
